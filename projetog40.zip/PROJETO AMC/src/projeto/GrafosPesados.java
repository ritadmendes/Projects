package projeto;

import java.util.ArrayList;
import java.util.Arrays;

public class GrafosPesados{
	     // pus o grafo como uma matriz de adjac�ncia em que cada entrada corresponde �s informa��es m�tuas 
		double MA[][];
		int dim;

	public GrafosPesados(int dim) {
			this.dim=dim;
			MA=new double [dim][dim];
		}
		
	public void add_edge(int o, int d, double p) {  
		if (o>=0 && o<dim && d>=0 && d<dim) {
			MA [o][d]=p;
			MA [d][o]=p;
		} else { 
			throw new AssertionError ("Error: node out of scope"); 
		} 
	}


	public String toString() {
		return  Arrays.deepToString(MA);
		//m�todo que permite imprimir matrizes
	}
	
	
	  public Floresta max_spanning_tree(Amostra amostra) { 
		int last=this.dim-1;	
	    boolean[] visitados = new boolean[this.dim];//guarda os n�s que j� foram visitados
	    ArrayList<Integer> avisitar=new ArrayList<Integer>();//guarda os n�s a visitar
	    for(int i=0;i<this.dim;i++) 
	       avisitar.add(i, 1); // adicionamos todos os n�s na lista a visitar 
        Floresta floresta=new Floresta(this.dim);//onde se vai, depois de j� termos as arestas no edges, tornar pais os n�s,de acordo com a diverg�ncia a partir da classe(maior n�)
	    visitados[last] = true;//come�amos por ver o �ltimo n� para garantir que a �rvore diverge a partir da classe 
	    avisitar.remove(0);  
	    for(int k=0;k<this.dim;k++) //para remover variaveis que sao independentes-nao tem info mutuas com nenhuma outra
	    	if(amostra.domain(k)==1) {
	    		visitados[k]=true;
	            avisitar.remove(0);
	            floresta.flor.set(k,tovector(-3));//para depois reconhecer esse valor na fun��o prob
	            // colocamos -3 como pai de uma vari�vel indepedente 
	    	}
	    while (!avisitar.isEmpty()) { // enquanto houver n�s por visitar 
        int ind_max=-1;//n� escolhido 
        int xfinal=last;//n� de partida
        double max_aux=-1;//peso maximo da aresta que o corte dos visitados pode percorrer	
	      for (int i = 0; i < this.dim; i++) {
	          if (visitados[i] == true)  {
	            for (int j = 0; j < this.dim; j++) {
	              // se j n�o for visitado e tem uma aresta com peso com i
	              if (visitados[j]==false && MA[i][j]!= 0 && MA[i][j]>max_aux) { 
	            	 max_aux=MA[i][j];
	                 ind_max=j;
	                 xfinal=i;
	            }
	          }	          
	          }}

	   	  floresta.set_parent(ind_max, xfinal);
	      visitados[ind_max] = true;
	      avisitar.remove(0);
	  }

	    
	    if (floresta.treeQ()) {
	       return floresta;
	    }
	      
	    else {
	    	System.out.println("A floresta obtida n�o � uma �rvore");
	    	return null;
		
	    }
	  }	
	
	
	  
	  public static int[] tovector(int i){ // s� para ficar mais eficiente
			int[] j=new int[1];
			j[0]=i;
			return j;
		}
	  public static int[] tovector2(int i,int k){ // s� para ficar mais eficiente
			int[] j=new int[2];
			j[0]=i;
			j[1]=k;
			return j;
		}
	  

	  
	  public static void main(String[] args) {
		  
//	  Amostra amostra = new Amostra("letter.csv");
//	  GrafosPesados g=amostra.PGrafo();
//      Floresta arvore=g.max_spanning_tree(amostra);
//	  RedesBayesianasArboreas rede=new RedesBayesianasArboreas(arvore,amostra,0.5);
//	  System.out.println(arvore);

	   
	  }
	}
