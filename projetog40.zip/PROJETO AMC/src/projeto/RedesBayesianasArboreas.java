package projeto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;


public class RedesBayesianasArboreas implements Serializable{
	private static final long serialVersionUID = 1L;
	Floresta arvore;
	Amostra dados;
	double S;
	ArrayList<double[][]> redebayes;
	
	//construtor BN 
	public RedesBayesianasArboreas(Floresta arvore, Amostra dados, double s) {
		this.arvore = arvore;
		this.dados = dados;
		S = s;
		ArrayList<double[][]>L=new ArrayList<double [][]>(); // lista de matrizes
		int ultimo=dados.element2(0).length-1;
		for (int o=0;o<ultimo;o++) { //queremos a distribui��o de cada n� menos da classe porque essa � diferente 
			int p=arvore.flor.get(o)[0] ; // vamos buscar o pai do n� que estamos a ver 
			double [][] MA=new double [dados.domain(o)][dados.domain(p)]; // para cada vari�vel h� uma matriz de adjac�ncia que tem dimens�es 
			// dom�nio da vari�vel e domn�nio do pai e nessa entrada est� a probabilidade tendo em conta esses valores
			for (int i=0;i<dados.domain(o);i++) { // para cada valor do dom�nio da vari�vel o
			   for (int j=0;j<dados.domain(p);j++) { //para cada valor do pai
				   if (p==-3) { // se a vari�vel for independente n�o � necess�rio calcular DFO porque vai ser sempre 1
					   MA[i][j]=1.0;
				   }
				   else {
				  int [] OP=Amostra.tovector2(o,p); // lista de vari�veis 
				  int []J=Amostra.tovector(j);
				  int [] P=Amostra.tovector(p);
				  int[]IJ=Amostra.tovector2(i,j); //lista de valores com o valor i da vari�vel O e com o valor j o pai  de i
			      double DFO=(dados.count(OP,IJ)+S)/(dados.count(P, J)+S*dados.domain(o)); // f�rmula 
			      MA[i][j]=DFO;}
			   }  
			}
		L.add(o, MA); // adicionamos na posi��o da vari�vel a matriz que foi calculada 
//			    
		}
		
		int cdomain=dados.domain(ultimo); // para a classe 
		double [][]C=new double[1][cdomain];//vetor da classe	
		for(int k=0;k<cdomain;k++) { // para cada valor que a classe pode tomar 
			double dfo=(dados.count(Amostra.tovector(ultimo),Amostra.tovector(k))+S)/(dados.length()+cdomain*S);
			C[0][k]=dfo;
		}
		L.add(ultimo,C);//p�e dfo�s da classe com um vetor na �ltima posi��o da lista l
			            // o �ltimo n� n�o tem pai, logo � apenas um vetor com os seus valores poss�veis
		
		 this.redebayes=L;	
		
		}
		
	
	
	@Override
	public String toString() {
		String s = null;
		s="[";
		for (int i=0; i<this.redebayes.size();i++) {
				s+="   "+Arrays.deepToString(redebayes.get(i));}
		s+="]";
				
		return " Rede = " + s;
	}




		public double prob(int [] v) { 
			// para cada vari�vel vamos buscar a probabilidade do valor
			double r=1;
			for (int o=0; o<v.length;o++) { //para cada vari�vel
				if(this.arvore.flor.get(o)[0]!=-3) { // se esta n�o for independente 
					int i=v[o]; // vemos o valor da vari�vel 
					if (i>=dados.domain(o) || i<0) // se este n�o pertencer ao dom�nio d� erro 
						throw new RuntimeException("na posi��o "+o+" colocou um valor que ultrapassa o dom�nio deste atributo");
				    if(o==v.length-1) // para a classe 
					   r*=this.redebayes.get(o)[0][i];
				    else {
				      int j=v[this.arvore.flor.get(o)[0]]; //tendo em conta o valor do pai da variav�l em quest�o
				      r*=this.redebayes.get(o)[i][j];
				  }
				}	
			}
			return r;	
		}

		public String classificar (int[] v, Amostra amostra){
			double maximo=-1;//maximo da probabilidade
			double soma=0.0; // armazena as v�rias probabilidades para depois calcular a percentagem 
			int classeprovavel=0; // classe mais prov�vel � a que possuir uma probabilidade maior 
			int ultimo=amostra.element2(0).length-1;
			for(int k=0;k<amostra.domain(ultimo);k++) { // para cada calor que a classe pode tomar 
				int[] n=Arrays.copyOf(v, ultimo+1); // cria um vetor com comprimento maior que o v mas com os elementos do v nas posi��es originais 
				n[ultimo]=k; // o �ltimo valor ser� o valor da classe para o qual queremos calcular a probabilidade 
				double probabilidade=this.prob(n); // vamos buscar a probabilidade desse vetor 
				soma+=probabilidade; // vamos adicionando as probabilidade para depois calcular a percentagem de prob 
				if(probabilidade>maximo) { // se a probabilidade calculada for maior ent essa passa a ser o valor de m�ximo da probabilidade 
					maximo=probabilidade;
					classeprovavel=k; // a classe mais prov�vel � ent�o a q possui esse valor 
				}
			}
			return "A classe mais prov�vel � "+classeprovavel+" e tem probabilidade de "+ ((maximo/soma) *100) +"%.";
		
				
			}
		
		public int classificar2 (int[] v, Amostra amostra){ // apenas utilizada no leave one out 
			double maximo=-1;//maximo da probabilidade
			int classeprovavel=0; // vai guardar a classe que possui maior probabilidade 
			int ultimo=amostra.element2(0).length-1; 
			for(int k=0;k<amostra.domain(ultimo);k++) { // percorre o domain da classe 
				int[] n=Arrays.copyOf(v, ultimo+1); // cria vetor com mais uma entrada que ir� corresponder � classe 
				n[ultimo]=k; // a classe vai tomar um valor do domain 
				double probabilidade=this.prob(n); // a probabilidade da classe ter esse valor 
				if(probabilidade>maximo) {
					maximo=probabilidade;
					classeprovavel=k; // se a probabilidade de ter esse valor for maior do que a encontrada at� agora 
					// ent�o atualiza-se o valor de probabilidade e o valor da classe para a qual ela toma esse maior valor de probabilidade 
				}
			}
			return classeprovavel; // retorna a classe com mais probabilidade 
		
				
			}
			
			
		
		public double leaveoneout() { // vai retirando os elementos da amostra 1 a 1, gerando uma nova amostra 
			// vai aprender essa nova amostra e receber o vetor que foi retirado sem a classe, e vai classific�-lo 
			// depois verifica se o valor de classe obtido � igual ao que o vetor possuia na amostra inicial 
			// caso o valor esteja correto conta como mais um caso de sucesso do classificador 
			double r=0;
			for(int i=0;i<dados.length();i++) {
				int [] vecamostra=dados.getList().get(i);
                int [] vetoraclassificar=Arrays.copyOf(vecamostra, vecamostra.length-1);
                Amostra novamostra=dados;
                novamostra.getList().remove(i);
				if(this.classificar2(vetoraclassificar, novamostra)==vecamostra[vecamostra.length-1])
					r+=1;
			}
			return r/(dados.length())*100;
		}

		    public static void main (String[] args) 
		    {
//		        Amostra amostra = new Amostra("letter.csv");
//				GrafosPesados g=amostra.PGrafo();
//				System.out.println("o grafo ja esta");
//				Floresta arvore=g.max_spanning_tree(amostra);
//				RedesBayesianasArboreas rede=new RedesBayesianasArboreas(arvore,amostra,0.5);
//                System.out.println(rede);
//                System.out.println(rede.leaveoneout());


		    }
}
		
		
