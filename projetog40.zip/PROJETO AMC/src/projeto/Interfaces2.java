package projeto;


//INTERFACES 2- Isto vai ler a rede de bayes do disco, e depois ao escrevemos um vetor com os atributos da amostra classifica a classe

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;

public class Interfaces2 {

	private JFrame frame;
	RedesBayesianasArboreas rede;
	

	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interfaces2 window = new Interfaces2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Interfaces2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public String classificar (RedesBayesianasArboreas rede,int[] v){
		double maximo=-1;//maximo da probabilidade
		double soma=0.0;
		int classeprovavel=0;
		int ultimo=rede.redebayes.size()-1;
		double[][] ultimovec=rede.redebayes.get(rede.redebayes.size()-1);
		for(int k=0;k<Array.getLength(ultimovec[0]);k++) {
			int[] n=Arrays.copyOf(v, ultimo+1);
			n[ultimo]=k;
			double probabilidade=rede.prob(n);
//			System.out.println(probabilidade);
			soma+=probabilidade;
			if(probabilidade>maximo) {
				maximo=probabilidade;
				classeprovavel=k;
			}
		}
		return "A classe mais prov�vel � "+classeprovavel+" e tem probabilidade de "+ ((maximo/soma) *100) +"%.";
	
			
		}
	
			

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(195, 38, 200, 20);
		frame.getContentPane().add(textArea);
		
		JFileChooser fileChooser = new JFileChooser();
		
		JButton btnNewButton = new JButton("Ler Rede");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 fileChooser.showOpenDialog(fileChooser);
					try {
						FileInputStream streamIn = new FileInputStream(fileChooser.getSelectedFile().getAbsolutePath());
						ObjectInputStream objectinputstream = new ObjectInputStream(streamIn);
					    rede = (RedesBayesianasArboreas) objectinputstream.readObject();
						objectinputstream.close();
						streamIn.close();
						
						textArea.setText("Rede read successfully!");
						
					
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				     
					
				}
			});
		btnNewButton.setBounds(29, 38, 133, 25);
		frame.getContentPane().add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(48, 134, 262, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setRows(2);
		textArea_1.setBounds(10, 188, 416, 65);
		frame.getContentPane().add(textArea_1);
		
		JButton btnCheck = new JButton("Classificar");
		btnCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String line = textField.getText();
				String cvsSplitBy = ",";
				String[] country     = line.split(cvsSplitBy);
				int[] stringToIntVec = new int[country.length];
				for (int i = 0; i < country.length; i++)
					stringToIntVec[i] = Integer.parseInt(country[i]);
				System.out.println(Arrays.toString(stringToIntVec));
				System.out.println(classificar(rede,stringToIntVec));
				textArea_1.setText(classificar(rede,stringToIntVec));

				
			}
		});
		btnCheck.setBounds(48, 163, 117, 25);
		frame.getContentPane().add(btnCheck);
		
		JLabel lblNewLabel = new JLabel("Escrever os par\u00E2metros separados por v\u00EDrgulas");
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 13));
		lblNewLabel.setBounds(48, 108, 310, 20);
		frame.getContentPane().add(lblNewLabel);
		
		

	}
}