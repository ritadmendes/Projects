package projeto;

//INTERFACES 1 -Tem um bot�o que procura a amostra no pc, e outro que grava a rede de bayes dessa amostra no pc

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class Interfaces {

	private JFrame frame;
	Amostra A;
	RedesBayesianasArboreas rede;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interfaces window = new Interfaces();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Interfaces() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(122, 157, 185, 46);
		frame.getContentPane().add(textArea);
		
		
		
		JFileChooser fileChooser = new JFileChooser();
		
		JButton btnNewButton = new JButton("Procurar amostra");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fileChooser.showOpenDialog(fileChooser);
				A = new Amostra(fileChooser.getSelectedFile().getAbsolutePath()); 
				GrafosPesados g=A.PGrafo();
				Floresta maximarvore=g.max_spanning_tree(A);
				rede=new RedesBayesianasArboreas(maximarvore,A,0.5); 
				textArea.setText("Clique agora em Gravar Rede");
				
			}
		});
		
		
		btnNewButton.setBounds(122, 34, 185, 30);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnDumpAmostra = new JButton("Gravar Rede");
		btnDumpAmostra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				FileOutputStream fout;
				try {
					fout = new FileOutputStream
							(fileChooser.getSelectedFile().getAbsolutePath() + "redegravada", true);
					ObjectOutputStream oos = new ObjectOutputStream(fout);
					oos.writeObject(rede);
//					System.out.println(rede);
					oos.close();
					fout.close();
					textArea.setText("Rede saved successfully!");
				
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    
			}
		});
		btnDumpAmostra.setBounds(122, 92, 185, 30);
		frame.getContentPane().add(btnDumpAmostra);
		

	}
}
