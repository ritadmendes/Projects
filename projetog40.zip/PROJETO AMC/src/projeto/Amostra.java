package projeto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Amostra implements Serializable { 
	private static final long serialVersionUID = 1L;

	private ArrayList<int []> list;
	
	public ArrayList<int[]> getList() { // utilizado nas interfaces 
		return list;
	}

	public Amostra() {
		this.list = new ArrayList<int []>();
	}

	public Amostra(String csvFile) {
		this.list = new ArrayList<int []>();;

		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] country     = line.split(cvsSplitBy);
				int[] stringToIntVec = new int[country.length];
				for (int i = 0; i < country.length; i++)
					stringToIntVec[i] = Integer.parseInt(country[i]);	
				add(stringToIntVec);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void add (int[] v){ // adiciona elemento v � amostra 
		list.add(v);
	}
	
	//length-retorna o n�mero de vetores dentro da lista
	public int length() { // retorna o comprimento da amostra 
		return list.size();
	}
	

	
	public int [] element2(int v) { // vai � amostra e retorna o elemento que est� na posi��o v
		if (v>=0 & v<this.length()) {
		return list.get(v);
	}
		else
			throw new RuntimeException("Erro: a posi��o tem que estar entre 0 e " + Integer.toString(length()-1));
}

	
	//domain
	public int domain(int p) { // retorna o dom�nio da varia�vel, que corresponde ao valor m�ximo que ela toma na amostra +1
		int resultado=0; 
	    if(p<(this.element2(0)).length && p>=0) { // percorremos as vari�veis da amostra 
			for(int i=0;i<this.length();i++) { // para cada vetor da amostra 
				int [] vetor=this.element2(i); // armazenamos o vetor que estamos a ver no momento 
	            if (vetor[p]>resultado) // se o valor da vari�vel nesse vetor for maior que o maior valor encontrado at� agora 
	        	  resultado=vetor[p]; // atualizamos o maior valor 
			}
	    }
		return resultado+1;	// retornamos o dom�nio 
	
	}			
		
	
	
	//count
	
	public int count(int[] variaveis,int[] valores) { // recebe um vetor de vari�veis e um vetor de valores e conta quantas vezes a vari�vel tem esse valor correspondente 
		if (variaveis.length==valores.length) { // assegura que os comrpimentos dos vetores recebidos s�o iguais 
		   int res=0;
		   for(int i=0;i<this.length();i++) { // percorre os vetores da amostra 
			  boolean presente=true; 
			  int [] vetor=this.element2(i); // armazena o vetor que estamos a ver no momento 
		      for(int j=0;j<variaveis.length;j++) { // +ara cada valor de vari�vel 
		    	int var=variaveis[j];//variavel que estamos a ver
			    if(var<(this.element2(0)).length && var>=0) { // assegura que a vari�vel est� presente na amostra 
                  //n�o sei se adiciono isto--throw new RuntimeException("As vari�veis digitadas n�o est�o presentes na amostra ");
			      int posicao=j;//posi��o da variavel que estamos a ver
			      if(valores[posicao]>=domain(var)) {  // assegura que o valor da vari�vel est� contidp na amostra 
			        presente=false; 
			        }
			      else {
                    if(vetor [var]!=valores[posicao]) // se o valor for diferente do que est� na posi��o 
			          presente=false;  
			      }
                  // n�o sei se ponho isto--throw new RuntimeException("Os valores t�m que estar no dom�nio das vari�veis");
				}
			    }
			  if (presente) // se se verificarem as condi��es 
				  res+=1; // adiconamos um ao resultado pq contamos uma 
			}
		return res;		
	}
		else
		 throw new RuntimeException("Erro: os vetores t�m que ter a mesma dimens�o");
	}
	      
	 
	@Override
	public String toString() {
		String s="[";
		if (list.size()>0) s+=Arrays.toString(list.get(0));
		for (int i=1; i<list.size();i++)  ///alteramos para i=1
			s+=","+Arrays.toString(list.get(i));
		s+="]";
			
		return " Amostra = " + s;
	}
	
	
	

	
	 public static int[] tovector(int i){ // s� para ficar mais eficiente
			int[] j=new int[1];
			j[0]=i;
			return j;
		}
	  public static int[] tovector2(int i,int k){ // s� para ficar mais eficiente
			int[] j=new int[2];
			j[0]=i;
			j[1]=k;
			return j;
		}
		
	  public  double infmutua(int o,int d) {//dadas duas vari�veis (dois n�s) 
		    double compamostra=this.length(); //Aqui tem de ser double porque n�o consegue fazer contas com int e doubles
			double r=0;
			int [] O=tovector(o);
			//transformar num vetor porque as fun��es que � preciso utilizar t�m como argumento vetores
			int [] D=tovector(d);
			for (int i=0;i<this.domain(o);i++) { // para cada valor poss�vel da vari�vel o
				 int [] I=tovector(i);
				 double nx=this.count(O,I);
				for (int j=0;j<this.domain(d);j++) { //para cada valor poss�bel da vari�vel d
					int [] J=tovector(j);
					int [] OD= tovector2(o,d);
					int[]IJ=tovector2(i,j);
					double countOD_IJ=this.count(OD,IJ);
					double countD_J=this.count(D,J);
					if (countOD_IJ/compamostra==0 && (countOD_IJ*compamostra)/(nx*countD_J)==0)
						r+=0; // assegurar que 0*log(0)=0
					 
					else {
						
					    r+=(countOD_IJ)*Math.log((countOD_IJ*compamostra)/(nx*countD_J));
					   
				}
			 }
			}
			r*=1/compamostra;
			return r;

		}	
	 
		  
		  public  GrafosPesados PGrafo(){ // cria um grafo em que as arestas t�m o valor das infmutua
			  int comprimento=this.element2(0).length;
			  GrafosPesados PGrafo= new GrafosPesados(comprimento);
			  for(int i=0;i<comprimento;i++) {
				  for(int j=0;j<comprimento;j++) {
					  if(PGrafo.MA[i][j]==0)
					     PGrafo.add_edge(i, j, infmutua(i,j));
				  }}
			  return PGrafo;
					  
		  }
	  
	  
	public static void main(String[] args) {
//		Amostra amostra = new Amostra("bcancer.csv");
//		int[] v= {0,1,2};
//	    int []valores= {1,0,0};
//		amostra.add(v);
//	System.out.println(amostra);
//		System.out.println(amostra.length());
//		System.out.println(amostra.element(682));
//		System.out.println(amostra.domain(v));
//		System.out.println(amostra.count(v,valores));	
//		System.out.println(amostra.PGrafo());
//		System.out.println(amostra.element2(0).length);
		
	}


}

