package projeto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Floresta implements Serializable {
	
	private static final long serialVersionUID = 1L;

	int n;
	ArrayList<int[]>flor;
	int[] k=new int[1];
	
	
	//m�todo construtor
    public Floresta(int n) {
		this.n = n;
		flor=new ArrayList<int[]>();
		k[0]=-1;
		for(int i=0;i<n;i++)
		flor.add(k);
		// a floresta est� definida como um vetor de pais, isto �, � uma ArrayList em que cada posi��o cont�m um vetor com os pais da vari�vel 
		// que corresponde �quela posi��o 
		
	}

// m�todo toString para conseguirmos ler
    @Override
	public String toString() {
    String s="[";
	if (flor.size()>0) s+=Arrays.toString(flor.get(0));
	for (int i=1; i<flor.size();i++)  ///alteramos para i=1
		s+=","+Arrays.toString(flor.get(i));
	s+="]";
		
	return " Floresta = " + s;
}
    
    public void set_parent(int n,int m) { // o pai vai ser o m
    	if (n>=0 & n<flor.size() & m>=0 & m<flor.size() ) {
    		int size=flor.get(n).length; //tamanho do vetor na posi��o n da floresta
    		int []j=Amostra.tovector(m);
    		if (flor.get(n)[0]!=-1) { //vamos � floresta na posi��o n e se for diferente de -1 (j� tem pelo menos um pai)
    			for(int v:flor.get(n)) { // se algum dos pais de n for m paramos porque j� l� est�
    				if (v==m)
    					break;
    				else { // no caso de a variavel ainda nao ter pai
    					int[] vetor=Arrays.copyOf(flor.get(n), size+1);//criamos um vetor onde vamos colocar o pai e vai ter tamanho size+1 para o pai caber l� tamb�m
    					vetor[size]=m; // e acrescentamos tamb�m o valor do novo pai (m)
    					flor.set(n, vetor);// na posi�ao n fica o vetor com o pai		
    			}
    		}
    			
    		}
    		else 
    			flor.set(n, j); 
    	
    	}
    	else
    		throw new RuntimeException("n e m t�m que ser maiores que 0 e menores que "+Integer.toString(flor.size()));
    }
	
   

//treeQ 
    public boolean treeQ() { // v� se a floresta � uma �rvore 
    	boolean r=true;
    	if (flor.get(flor.size()-1)[0]!=-1) // maior n� � a raiz que n�o tem nenhum pai
    		r=false;
    	for(int i=0;i<this.n-1;i++) {
    		if(flor.get(i).length>=2) // se cada n� tiver mais que um pai n�o � uma �rvore 
    			r=false;
    		else { //sem ser a raiz todos os nos t�m no m�ximo um pai
    			for(int x:flor.get(i)) {
    				if(x==-1)    
    				   r=false;
    			}
    	}
    	}
    	return r;
      }
    
    
    

	public static void main(String args[]) {
//    	Floresta flora=new Floresta(3);
//  	    flora.set_parent(0,1);
// 	    flora.set_parent(1,0);
//        System.out.println(flora);
//    	System.out.println(flora.treeQ());
//		
	}
}
